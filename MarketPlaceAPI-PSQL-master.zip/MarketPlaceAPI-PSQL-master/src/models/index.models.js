module.exports = {
    Product: require("./product.model")
};
